﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio01
{
    internal class Exercicio01
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o valor em Real: ");
            var valorReal = int.Parse(Console.ReadLine());

            Console.WriteLine("O valor em dolar é: " + (valorReal * 0.193259));
        }
    }
}
