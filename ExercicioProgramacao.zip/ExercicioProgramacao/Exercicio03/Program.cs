﻿namespace Exercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite a distância percorrida em Km: ");
            var valorKm = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o consumo em Litros: ");
            var valorLts = double.Parse(Console.ReadLine());

            Console.WriteLine("O consumo médio é de " + (valorKm / valorLts) + "Km/L");
        }
    }
}