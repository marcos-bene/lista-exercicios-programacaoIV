﻿namespace Exercicio04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite seu ano de nascimento: ");
            var anoNascimento = int.Parse(Console.ReadLine());

            Console.WriteLine("Sua idade é " + (2024 - anoNascimento));                
        }
    }
}