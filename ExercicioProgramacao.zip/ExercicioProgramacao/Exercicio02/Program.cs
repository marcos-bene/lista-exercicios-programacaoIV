﻿namespace Exercicio02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o valor em Dolar: ");
            var valorDolar = int.Parse(Console.ReadLine());

            Console.WriteLine("O valor em dolar é: " + (valorDolar * 5.22));
        }
    }
}