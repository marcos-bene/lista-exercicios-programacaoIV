﻿namespace Exercicio09
{
    struct Livro
    {
        public string Titulo;
        public string Autor;
        public double Valor;

        public override string ToString()
        {
            return $"Título: {Titulo}\nAutor: {Autor}\nValor: R$ {Valor:F2}";
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Livro livro;

            Console.WriteLine("Cadastro de Livro");
            Console.Write("Digite o título do livro: ");
            livro.Titulo = Console.ReadLine();

            Console.Write("Digite o autor do livro: ");
            livro.Autor = Console.ReadLine();

            Console.Write("Digite o valor do livro: ");
            if (!double.TryParse(Console.ReadLine(), out livro.Valor))
            {
                Console.WriteLine("Valor inválido! Por favor, digite um número válido.");
                return;
            }

            Console.WriteLine("\nDados do Livro:");
            Console.WriteLine(livro);
        }
    }
}