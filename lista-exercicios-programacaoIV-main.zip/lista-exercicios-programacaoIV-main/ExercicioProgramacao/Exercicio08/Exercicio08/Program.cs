﻿namespace Exercicio08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o seu nome:");
            string nome = Console.ReadLine();

            Console.WriteLine("Digite a sua data de nascimento (no formato DD/MM/AAAA):");
            string dataNascimentoStr = Console.ReadLine();

            if (DateTime.TryParse(dataNascimentoStr, out DateTime dataNascimento))
            {
                string faixaEtaria = DeterminarFaixaEtaria(dataNascimento);
                Console.WriteLine($"Caro(a) {nome}, você está na faixa etária de {faixaEtaria}.");
            }
            else
            {
                Console.WriteLine("Formato de data inválido. Por favor, digite a data de nascimento no formato correto.");
            }
        }

        static string DeterminarFaixaEtaria(DateTime dataNascimento)
        {
            DateTime dataAtual = DateTime.Today;
            int idade = dataAtual.Year - dataNascimento.Year;

            if (dataNascimento.Date > dataAtual.AddYears(-idade))
                idade--;

            if (idade >= 0 && idade <= 19)
            {
                return "Jovem";
            }
            else if (idade >= 20 && idade <= 59)
            {
                return "Adulto";
            }
            else
            {
                return "Idoso";
            }
        }
    }
}