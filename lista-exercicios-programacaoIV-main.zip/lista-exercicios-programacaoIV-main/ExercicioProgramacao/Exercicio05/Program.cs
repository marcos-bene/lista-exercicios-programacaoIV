﻿namespace Exercicio05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Escolha a operação:");
                Console.WriteLine("1 - Soma");
                Console.WriteLine("2 - Subtração");
                Console.WriteLine("3 - Multiplicação");
                Console.WriteLine("4 - Divisão");
                Console.WriteLine("5 - Resto da Divisão");
                Console.WriteLine("0 - Sair");
                Console.Write("Digite o número da operação desejada: ");

                int operacao;
                if (!int.TryParse(Console.ReadLine(), out operacao))
                {
                    Console.WriteLine("Opção inválida! Por favor, digite um número válido.");
                    continue;
                }

                if (operacao == 0)
                {
                    Console.WriteLine("Saindo...");
                    break;
                }

                double numero1, numero2;
                Console.Write("Digite o primeiro número: ");
                if (!double.TryParse(Console.ReadLine(), out numero1))
                {
                    Console.WriteLine("Número inválido! Por favor, digite um número válido.");
                    continue;
                }

                Console.Write("Digite o segundo número: ");
                if (!double.TryParse(Console.ReadLine(), out numero2))
                {
                    Console.WriteLine("Número inválido! Por favor, digite um número válido.");
                    continue;
                }

                double resultado = 0;
                string operacaoStr = "";
                switch (operacao)
                {
                    case 1:
                        resultado = numero1 + numero2;
                        operacaoStr = "soma";
                        break;
                    case 2:
                        resultado = numero1 - numero2;
                        operacaoStr = "subtração";
                        break;
                    case 3:
                        resultado = numero1 * numero2;
                        operacaoStr = "multiplicação";
                        break;
                    case 4:
                        if (numero2 != 0)
                        {
                            resultado = numero1 / numero2;
                            operacaoStr = "divisão";
                        }
                        else
                        {
                            Console.WriteLine("Não é possível dividir por zero!");
                            continue;
                        }
                        break;
                    case 5:
                        if (numero2 != 0)
                        {
                            resultado = numero1 % numero2;
                            operacaoStr = "resto da divisão";
                        }
                        else
                        {
                            Console.WriteLine("Não é possível dividir por zero!");
                            continue;
                        }
                        break;
                    default:
                        Console.WriteLine("Opção inválida! Por favor, escolha uma operação válida.");
                        continue;
                }

                Console.WriteLine($"O resultado da {operacaoStr} é: {resultado}\n");
            }
        }
    }
}

