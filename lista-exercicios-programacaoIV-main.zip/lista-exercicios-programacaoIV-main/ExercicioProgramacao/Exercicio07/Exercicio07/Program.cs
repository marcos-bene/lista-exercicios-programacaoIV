﻿namespace Exercicio07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o seu nome:");
            string nome = Console.ReadLine();

            int quantidadeConsoantes = ContarConsoantes(nome);

            Console.WriteLine($"O nome \"{nome}\" possui {quantidadeConsoantes} consoantes.");
        }

        static int ContarConsoantes(string texto)
        {
            int contadorConsoantes = 0;
            foreach (char caractere in texto)
            {
                // Verifica se o caractere é uma letra do alfabeto e não é uma vogal
                if (char.IsLetter(caractere) && !"aeiouAEIOU".Contains(caractere))
                {
                    contadorConsoantes++;
                }
            }
            return contadorConsoantes;
        }
    }
}

