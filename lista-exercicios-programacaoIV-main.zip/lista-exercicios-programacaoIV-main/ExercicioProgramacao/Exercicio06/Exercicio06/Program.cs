﻿namespace Exercicio06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o seu nome:");
            string nome = Console.ReadLine();

            int quantidadeVogais = ContarVogais(nome);

            Console.WriteLine($"O nome \"{nome}\" possui {quantidadeVogais} vogais.");
        }

        static int ContarVogais(string texto)
        {
            int contadorVogais = 0;
            foreach (char caractere in texto)
            {
                // Verifica se o caractere é uma vogal, ignorando se é maiúscula ou minúscula
                if ("aeiouAEIOU".IndexOf(caractere) != -1)
                {
                    contadorVogais++;
                }
            }
            return contadorVogais;
        }
    }
}


