﻿namespace Exercicio10._1
{
    internal class Program
    {
        static List<Aluno> alunos = new List<Aluno>();

        static void Main(string[] args)
        {
            int opcao;
            do
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1 - Cadastro de Alunos");
                Console.WriteLine("2 - Cadastro de Notas");
                Console.WriteLine("3 - Cadastro Total de Faltas");
                Console.WriteLine("4 - Relação de Alunos, Notas, Média, Faltas e Situação");
                Console.WriteLine("0 - Sair");
                Console.Write("Escolha uma opção: ");
                if (!int.TryParse(Console.ReadLine(), out opcao))
                {
                    Console.WriteLine("Opção inválida! Por favor, escolha uma opção válida.");
                    continue;
                }

                switch (opcao)
                {
                    case 1:
                        CadastrarAluno();
                        break;
                    case 2:
                        CadastrarNotas();
                        break;
                    case 3:
                        CadastrarFaltas();
                        break;
                    case 4:
                        ListarAlunos();
                        break;
                    case 0:
                        Console.WriteLine("Saindo...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida! Por favor, escolha uma opção válida.");
                        break;
                }

            } while (opcao != 0);
        }

        static void CadastrarAluno()
        {
            Console.WriteLine("Cadastro de Aluno");
            Aluno aluno = new Aluno();
            Console.Write("Digite o nome do aluno: ");
            aluno.Nome = Console.ReadLine();
            Console.Write("Digite o RA do aluno: ");
            aluno.RA = Console.ReadLine();
            alunos.Add(aluno);
            Console.WriteLine("Aluno cadastrado com sucesso!\n");
        }

        static void CadastrarNotas()
        {
            Console.WriteLine("Cadastro de Notas");
            Console.Write("Digite o RA do aluno: ");
            string ra = Console.ReadLine();
            Aluno aluno = alunos.Find(a => a.RA == ra);
            if (aluno != null)
            {
                Console.Write("Digite a nota da prova (máximo 10): ");
                if (!double.TryParse(Console.ReadLine(), out double notaProva) || notaProva < 0 || notaProva > 10)
                {
                    Console.WriteLine("Nota inválida! A nota deve ser um número entre 0 e 10.");
                    return;
                }
                aluno.NotaProva = notaProva;

                Console.Write("Digite a nota do trabalho (máximo 10): ");
                if (!double.TryParse(Console.ReadLine(), out double notaTrabalho) || notaTrabalho < 0 || notaTrabalho > 10)
                {
                    Console.WriteLine("Nota inválida! A nota deve ser um número entre 0 e 10.");
                    return;
                }
                aluno.NotaTrabalho = notaTrabalho;

                Console.WriteLine("Notas cadastradas com sucesso!\n");
            }
            else
            {
                Console.WriteLine("Aluno não encontrado!\n");
            }
        }

        static void CadastrarFaltas()
        {
            Console.WriteLine("Cadastro de Faltas");
            Console.Write("Digite o RA do aluno: ");
            string ra = Console.ReadLine();
            Aluno aluno = alunos.Find(a => a.RA == ra);
            if (aluno != null)
            {
                Console.Write("Digite o total de faltas do aluno: ");
                if (!int.TryParse(Console.ReadLine(), out int totalFaltas) || totalFaltas < 0)
                {
                    Console.WriteLine("Valor inválido! O total de faltas deve ser um número inteiro positivo.");
                    return;
                }
                aluno.TotalFaltas = totalFaltas;
                Console.WriteLine("Faltas cadastradas com sucesso!\n");
            }
            else
            {
                Console.WriteLine("Aluno não encontrado!\n");
            }
        }

        static void ListarAlunos()
        {
            Console.WriteLine("Relação de Alunos, Notas, Média, Faltas e Situação");
            foreach (var aluno in alunos)
            {
                Console.WriteLine($"Nome: {aluno.Nome}");
                Console.WriteLine($"RA: {aluno.RA}");
                Console.WriteLine($"Nota da prova: {aluno.NotaProva}");
                Console.WriteLine($"Nota do trabalho: {aluno.NotaTrabalho}");
                Console.WriteLine($"Média: {aluno.CalcularMedia():F2}");
                Console.WriteLine($"Total de faltas: {aluno.TotalFaltas}");
                Console.WriteLine($"Percentual de frequência: {aluno.CalcularFrequenciaPercentual():F2}%");
                Console.WriteLine($"Situação: {aluno.Situacao()}\n");
            }
        }
    }
}