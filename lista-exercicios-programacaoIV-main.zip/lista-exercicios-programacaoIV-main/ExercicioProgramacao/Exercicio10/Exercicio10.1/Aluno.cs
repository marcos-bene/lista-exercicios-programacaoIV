﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio10._1
{
    internal class Aluno
    {
        public string Nome { get; set; }
        public string RA { get; set; }
        public double NotaProva { get; set; }
        public double NotaTrabalho { get; set; }
        public int TotalFaltas { get; set; }

        public double CalcularMedia()
        {
            return (NotaProva * 7 + NotaTrabalho * 3) / 10;
        }

        public double CalcularFrequenciaPercentual()
        {
            double totalAulas = 25;
            double frequencia = (totalAulas - TotalFaltas) / totalAulas * 100;
            return frequencia;
        }

        public string Situacao()
        {
            double media = CalcularMedia();
            double frequencia = CalcularFrequenciaPercentual();

            if (media >= 7 && frequencia >= 75)
            {
                return "APROVADO";
            }
            else
            {
                return "REPROVADO";
            }
        }
    }
}
